var express = require("express");
var app = express();
app.use(express.static(__dirname));
app.get("/", function(req, res){
    res.sendFile(__dirname+"/step12-modules.html");
})
app.listen(1234);
console.log("server is now live on localhost:1234");