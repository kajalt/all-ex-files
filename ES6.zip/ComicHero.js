import {Hero} from "./Hero.js";

export class ComicHero extends Hero{
    constructor(htitle, hfname, hlname,city){
        super(htitle, hfname, hlname);
        this.city = city;
    }
    sayCity(){
        return this.city
    }
}