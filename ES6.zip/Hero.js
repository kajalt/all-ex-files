export class Hero{
    constructor(htitle, hfname, hlname){
        this.title = htitle;
        this.fname = hfname;
        this.lname = hlname;
    }
    fullname(){
        return this.fname+" "+this.lname
    }
};